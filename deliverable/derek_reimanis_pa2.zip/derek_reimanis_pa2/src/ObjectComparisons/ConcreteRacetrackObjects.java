package ObjectComparisons;


/** 
 * Concrete class, instantiating RacetrackComparisons. 
 * 
 * @author derek.reimanis
 *
 */
public class ConcreteRacetrackObjects extends RacetrackComparisons {
	/**
	 * Empty constructor
	 */
	public ConcreteRacetrackObjects() {
		
	}

}

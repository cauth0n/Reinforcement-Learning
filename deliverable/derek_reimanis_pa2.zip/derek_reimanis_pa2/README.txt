Greetings!

Welcome to the racetrack!

Value Iteration is working just fine.

Q Learning is implemented, but has some bugs -- specifically with object to object comparisons.

The .data directory contains a directory of sample runs, a results directory, and a directory of all tracks used

The sample runs directory has a list of 100 simulations run on the L track, with no reset upon collision.
There also exists a one-time path of a collision on the Z track.

The results directory documents the results of all the tracks I used.

To run the .jar, type:
java -jar -Xms1024M -Xmx4096M super_slick_racer.jar
into the command prompt! The L-track is enabled by default.

:D
